<?php
session_start();

// Proteção: só acessa se estiver logado e for assinante nv3
$cx = new mysqli("127.0.0.1", "u839226731_cztuap", "Meu6595869Trator", "u839226731_meutrator");
if ($cx->connect_error) {
    die("Erro na conexão: " . $cx->connect_error);
}

$username = $_SESSION['username_odonto2'] ?? '';


/// Paginação
$limite = 8; // imóveis por página
$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
if ($pagina < 1) $pagina = 1;
$offset = ($pagina - 1) * $limite;

// Processa pesquisa SEM necessidade de clicar em "Pesquisar"
$garagem = $_POST['garagem'] ?? $_GET['garagem'] ?? '';
$quartos = $_POST['quartos'] ?? $_GET['quartos'] ?? '';
$cidade = $_POST['cidade'] ?? $_GET['cidade'] ?? '';
$estado = $_POST['estado'] ?? $_GET['estado'] ?? '';
$bairro = $_POST['bairro'] ?? $_GET['bairro'] ?? '';
$tipo = $_POST['tipo'] ?? $_GET['tipo'] ?? '';
$contrato = $_POST['contrato'] ?? $_GET['contrato'] ?? '';
$preco_min = $_POST['preco_min'] ?? $_GET['preco_min'] ?? '';
$preco_max = $_POST['preco_max'] ?? $_GET['preco_max'] ?? '';
$banheiros = $_POST['banheiros'] ?? $_GET['banheiros'] ?? '';




$sql = "SELECT SQL_CALC_FOUND_ROWS * FROM compact_imoveis WHERE 1=1";
$params = [];
$types = "";
if (!empty($banheiros)) { 
    $sql .= " AND banheiros=?"; 
    $params[] = $banheiros; 
    $types .= "i"; 
}
if (!empty($preco_min)) { $sql .= " AND preco >= ?"; $params[] = $preco_min; $types .= "d"; }
if (!empty($preco_max)) { $sql .= " AND preco <= ?"; $params[] = $preco_max; $types .= "d"; }
if (!empty($garagem)) { $sql .= " AND garagem=?"; $params[] = $garagem; $types .= "i"; }
if (!empty($quartos)) { $sql .= " AND dormitorios=?"; $params[] = $quartos; $types .= "i"; }
if (!empty($cidade)) { $sql .= " AND cidade=?"; $params[] = $cidade; $types .= "s"; }
if (!empty($estado)) { $sql .= " AND estado=?"; $params[] = $estado; $types .= "s"; }
if (!empty($bairro)) { $sql .= " AND bairro=?"; $params[] = $bairro; $types .= "s"; }
if (!empty($tipo)) { $sql .= " AND tipo=?"; $params[] = $tipo; $types .= "s"; }
if (!empty($contrato)) { $sql .= " AND contrato=?"; $params[] = $contrato; $types .= "s"; }

$sql .= " ORDER BY id DESC LIMIT ? OFFSET ?";
$params[] = $limite;
$params[] = $offset;
$types .= "ii";

$stmt = $cx->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$resultados = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Total de registros
$totalResult = $cx->query("SELECT FOUND_ROWS() as total")->fetch_assoc()['total'];
$totalPaginas = ceil($totalResult / $limite);

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta name="description" content="Encontre imóveis para aluguel e venda em Carlito's Locações. Casas, apartamentos, chácaras e terrenos em diversas cidades, com fotos e informações completas.">
<meta name="keywords" content="imóveis, aluguel, venda, casas, apartamentos, Carlito's Locações, Palmeira das Missões, Rio Grande do Sul">
<meta name="author" content="Carlito's Locações">

<!-- Open Graph -->
<meta property="og:title" content="Carlito's Locações - Pesquisa de Imóveis">
<meta property="og:description" content="Pesquise imóveis disponíveis para aluguel e venda. Veja fotos, preços e detalhes completos.">
<meta property="og:image" content="https://carlitoslocacoes.com/todofarol/cf.png">
<meta property="og:url" content="https://carlitoslocacoes.com/compact">
<meta property="og:type" content="website">

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Carlito's Locações - Pesquisa de Imóveis">
<meta name="twitter:description" content="Pesquise imóveis disponíveis para aluguel e venda. Veja fotos, preços e detalhes completos.">
<meta name="twitter:image" content="https://carlitoslocacoes.com/todofarol/cf.png">

<meta charset="UTF-8">
<title>Pesquisa de Imóveis</title>
<style>
body {
  margin: 0;
  font-family: Arial, sans-serif;
  background: linear-gradient(135deg, #000000 50%, #b30000 50%);
  color: #fff;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: flex-start;
}

.container {
  display: flex;
  flex-direction: row;
  width: 95%;
  max-width: 1200px;
  margin-top: 20px;
  gap: 20px;
}

/* Coluna do formulário */
.form-col {
  flex: 1;
  background: rgba(0,0,0,0.8);
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 0 15px rgba(255,0,0,0.6);
}

/* Coluna dos resultados */
.results-col {
  flex: 2;
  display: flex;
  flex-direction: column;
  gap: 15px;
}

label {
  display: block;
  margin-top: 10px;
  font-weight: bold;
  color: #ff3333;
}
input, select, button {
  width: 100%;
  padding: 10px;
  margin-top: 5px;
  border: none;
  border-radius: 5px;
  font-size: 1em;
}
input, select {
  background: #1a1a1a;
  color: #fff;
}
button {
  background: #b30000;
  color: #fff;
  font-weight: bold;
  cursor: pointer;
  margin-top: 20px;
  transition: 0.3s;
}
button:hover {
  background: #ff1a1a;
}
.resultado {
  background: rgba(0,0,0,0.7);
  padding: 15px;
  border-radius: 8px;
}
.resultado img {
  max-width: 100%;
  margin-top: 10px;
  border-radius: 5px;
}

/* Paginação */
.pagination {
  margin-top: 20px;
  text-align: center;
}
.pagination a {
  display: inline-block;
  padding: 8px 12px;
  margin: 2px;
  background: #1a1a1a;
  color: #fff;
  border-radius: 5px;
  text-decoration: none;
}
.pagination a:hover {
  background: #b30000;
}
.pagination a.active {
  background: #ff1a1a;
  font-weight: bold;
}

/* Responsividade */
@media (max-width: 768px) {
  .container {
    flex-direction: column;
  }
}
</style>
</head>
<body>

<div class="container">
  <!-- Coluna do formulário -->
  <div class="form-col">
    <h2>Pesquisa de Imóveis</h2>
    <form method="POST">
        <label>Preço Mínimo:</label>
<input type="number" step="0.01" name="preco_min" placeholder="Ex: 500.00">

<label>Preço Máximo:</label>
<input type="number" step="0.01" name="preco_max" placeholder="Ex: 2000.00">

      <label>Quantidade de Garagem:</label>
      <input type="number" placeholder="Ex: 1, 2, 3." name="garagem" min="0">

      <label>Quantidade de Quartos:</label>
      <input type="number" placeholder="Ex: 1, 2, 3." name="quartos" min="0">
<label>Quantidade de Banheiros:</label>
<input type="number" placeholder="Ex: 1, 2, 3." name="banheiros" min="0">

      <label>Cidade:</label>
      <input type="text" placeholder="Ex: Palmeira das Missões" name="cidade">

      <label>Estado:</label>
      <input type="text" placeholder="Ex: Rio Grande do Sul" name="estado">

      <label>Bairro:</label>
      <input type="text" placeholder="Ex: Lutz" name="bairro">

      <label>Tipo:</label>
      <select name="tipo">
        <option value="">--Selecione--</option>
        <option>Quarto</option>
        <option>Apartamento</option>
        <option>Casa</option>
        <option>Chácara</option>
        <option>Comercial</option>
        <option>Sítio</option>
        <option>Terreno</option>
      </select>

      <label>Contrato:</label>
      <select name="contrato">
        <option value="">--Selecione--</option>
        <option>Aluguel</option>
      </select>

      <button type="submit">Pesquisar</button>
    </form>
  </div>
<div style="text-align:center; margin-top:30px;">
  <a href="painel.php" 
     style="display:inline-block; padding:12px 20px; background:#b30000; color:#fff; 
            font-weight:bold; border-radius:5px; text-decoration:none; transition:0.3s;">
    Ir para o Painel
  </a>
</div>

  <!-- Coluna dos resultados -->
  <div class="results-col">
   <?php foreach ($resultados as $imovel): ?>
  <div class="resultado">
       <?php if (!empty($imovel['link_principal'])): ?>
      <img src="<?php echo $imovel['link_principal']; ?>" alt="Foto Principal">
    <?php endif; ?>
    <strong><?php echo $imovel['tipo']; ?></strong><br>
    Contrato: <?php echo $imovel['contrato']; ?><br>
    Quartos: <?php echo $imovel['dormitorios']; ?> | Banheiros: <?php echo $imovel['banheiros']; ?> | Garagem: <?php echo $imovel['garagem']; ?><br>
    Endereço: <?php echo $imovel['rua']." ".$imovel['numero'].", ".$imovel['bairro']." - ".$imovel['cidade']."/".$imovel['estado']; ?><br>
    Telefone: <?php echo $imovel['telefone_site']; ?><br>
       <p><strong>Preço por dia:</strong> R$ <?php echo number_format($imovel['preco'], 2, ',', '.'); ?></p>

    <form method="GET" action="ver_imovel.php" style="margin-top:10px;">
      <input type="hidden" name="id" value="<?php echo $imovel['id']; ?>">
      <button type="submit">Ver Imóvel</button>
    </form>
  </div>
<?php endforeach; ?>

    <!-- Paginação -->
    <?php if ($totalPaginas > 1): ?>
      <div class="pagination">
        <?php if ($pagina > 1): ?>
          <a href="?pagina=<?php echo $pagina-1; ?>">Anterior</a>
        <?php endif; ?>

        <?php for ($i=1; $i <= $totalPaginas; $i++): ?>
          <a href="?pagina=<?php echo $i; ?>" 
             class="<?php echo ($i==$pagina)?'active':''; ?>">
             <?php echo $i; ?>
          </a>
        <?php endfor; ?>

        <?php if ($pagina < $totalPaginas): ?>
          <a href="?pagina=<?php echo $pagina+1; ?>">Próxima</a>
        <?php endif; ?>
      </div>
    <?php endif; ?>

  </div>
</div>
<footer>A Carlito’s Locações é um site publicitário. Sempre confira os documentos do imóvel e do proprietário antes de fechar negócio!</footer>
</body>
</html>
