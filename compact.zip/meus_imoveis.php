<?php
session_start();

// Conexão com o banco
$cx = new mysqli("127.0.0.1", "u839226731_cztuap", "Meu6595869Trator", "u839226731_meutrator");
if ($cx->connect_error) {
    die("Erro na conexão: " . $cx->connect_error);
}

// Usuário logado
$username = $_SESSION['username_odonto2'] ?? 'sistema';

// Mensagem de feedback
$msg = "";

// Exclusão por ID
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['id_excluir'])) {
    $idExcluir = (int)$_POST['id_excluir'];

    // Verifica se pertence ao usuário
    $stmtCheck = $cx->prepare("SELECT usuario_cadastro FROM compact_imoveis WHERE id=?");
    $stmtCheck->bind_param("i", $idExcluir);
    $stmtCheck->execute();
    $dados = $stmtCheck->get_result()->fetch_assoc();
    $stmtCheck->close();

    if ($dados && $dados['usuario_cadastro'] === $username) {
        $stmtDel = $cx->prepare("DELETE FROM compact_imoveis WHERE id=?");
        $stmtDel->bind_param("i", $idExcluir);
        $stmtDel->execute();
        $msg = "<p style='color:lime;'>Imóvel ID $idExcluir excluído com sucesso!</p>";
    } else {
        $msg = "<p style='color:red;'>🚫 Você não tem permissão para excluir este imóvel ou ele não existe.</p>";
    }
}

// Paginação inteligente para listar imóveis do usuário
$limite = 8;
$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
if ($pagina < 1) $pagina = 1;
$offset = ($pagina - 1) * $limite;

$stmt = $cx->prepare("SELECT SQL_CALC_FOUND_ROWS * FROM compact_imoveis WHERE usuario_cadastro=? ORDER BY id DESC LIMIT ? OFFSET ?");
$stmt->bind_param("sii", $username, $limite, $offset);
$stmt->execute();
$resultados = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$totalResult = $cx->query("SELECT FOUND_ROWS() as total")->fetch_assoc()['total'];
$totalPaginas = ceil($totalResult / $limite);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Excluir Imóvel por ID</title>
<style>
body {
  margin: 0;
  font-family: Arial, sans-serif;
  background: linear-gradient(135deg, #000000 50%, #b30000 50%);
  color: #fff;
  min-height: 100vh;
  padding: 20px;
}
.container {
  max-width: 1000px;
  margin: auto;
}
.resultado {
  background: rgba(0,0,0,0.7);
  padding: 15px;
  border-radius: 8px;
  margin-bottom: 15px;
}
button {
  background: #b30000;
  color: #fff;
  font-weight: bold;
  cursor: pointer;
  padding: 8px 12px;
  border: none;
  border-radius: 5px;
  transition: 0.3s;
}
button:hover { background: #ff1a1a; }
.pagination { margin-top: 20px; text-align: center; }
.pagination a {
  display: inline-block; padding: 8px 12px; margin: 2px;
  background: #1a1a1a; color: #fff; border-radius: 5px; text-decoration: none;
}
.pagination a:hover { background: #b30000; }
.pagination a.active { background: #ff1a1a; font-weight: bold; }
</style>
</head>
<body>
<div class="container">
  <h2>Excluir Imóvel por ID</h2>
  <?php echo $msg; ?>

  <!-- Formulário para excluir por ID -->
  <form method="POST" style="margin-bottom:20px;">
    <label>Digite o ID do imóvel para excluir:</label><br>
    <input type="number" name="id_excluir" required>
    <button type="submit">Excluir</button>
  </form>

  <h3>Meus Imóveis</h3>
  <?php foreach ($resultados as $imovel): ?>
    <div class="resultado">
      <strong>ID <?php echo $imovel['id']; ?> - <?php echo $imovel['tipo']; ?></strong><br>
      Contrato: <?php echo $imovel['contrato']; ?><br>
      Quartos: <?php echo $imovel['dormitorios']; ?> | Banheiros: <?php echo $imovel['banheiros']; ?> | Garagem: <?php echo $imovel['garagem']; ?><br>
      Endereço: <?php echo $imovel['rua']." ".$imovel['numero'].", ".$imovel['bairro']." - ".$imovel['cidade']."/".$imovel['estado']; ?><br>
      Telefone do Dono: <?php echo $imovel['telefone_dono']; ?><br>
      Telefone do Site: <?php echo $imovel['telefone_site']; ?><br>
    </div>
  <?php endforeach; ?>

  <!-- Paginação -->
  <?php if ($totalPaginas > 1): ?>
    <div class="pagination">
      <?php if ($pagina > 1): ?>
        <a href="?pagina=<?php echo $pagina-1; ?>">Anterior</a>
      <?php endif; ?>
      <?php for ($i=1; $i <= $totalPaginas; $i++): ?>
        <a href="?pagina=<?php echo $i; ?>" class="<?php echo ($i==$pagina)?'active':''; ?>">
          <?php echo $i; ?>
        </a>
      <?php endfor; ?>
      <?php if ($pagina < $totalPaginas): ?>
        <a href="?pagina=<?php echo $pagina+1; ?>">Próxima</a>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</div>
</body>
</html>
