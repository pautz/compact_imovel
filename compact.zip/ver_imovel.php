<?php
session_start();

// Conexão MySQLi
$cx = new mysqli("127.0.0.1", "u839226731_cztuap", "Meu6595869Trator", "u839226731_meutrator");
if ($cx->connect_error) { 
    die("Erro na conexão: " . $cx->connect_error); 
}

// Pega ID do imóvel
$id = $_GET['id'] ?? 0;
$stmt = $cx->prepare("SELECT * FROM compact_imoveis WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$imovel = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Pega fotos
$stmtFotos = $cx->prepare("SELECT * FROM compact_fotos WHERE imovel_id=?");
$stmtFotos->bind_param("i", $id);
$stmtFotos->execute();
$fotos = $stmtFotos->get_result()->fetch_all(MYSQLI_ASSOC);
$stmtFotos->close();

// Valores do imóvel
$valor_compra   = intval($imovel['preco']); 
$id_compra      = $imovel['id'];
$usuario_aura   = "carlitopautz_farolqr";

// Link de pagamento Aura
$link_pagamento_aura = "https://carlitoslocacoes.com/pulse/{$usuario_aura}.php?valor={$valor_compra}&compra_id={$id_compra}";

// Verificação de transação no mesmo dia
$data_atual = date('Y-m-d');
$sql = "SELECT COUNT(*) as total 
        FROM transacoes_aura 
        WHERE compra_id = ? 
          AND DATE(data_transacao) = ?";

$stmtTransacao = $cx->prepare($sql);
$stmtTransacao->bind_param("is", $id_compra, $data_atual);
$stmtTransacao->execute();
$resultado_consulta = $stmtTransacao->get_result()->fetch_assoc();
$stmtTransacao->close();

// Se não vier nada, força total = 0
$total_transacoes = $resultado_consulta ? (int)$resultado_consulta['total'] : 0;
?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <?php
// Monta dados para SEO
$tituloSEO = $imovel['tipo']." em ".$imovel['bairro']." - ".$imovel['cidade']."/".$imovel['estado'];
$descricaoSEO = "Imóvel disponível para ".$imovel['contrato']." em ".$imovel['bairro'].", ".$imovel['cidade']."/".$imovel['estado'].". 
Preço por dia: R$ ".number_format($imovel['preco'], 2, ',', '.').". 
Telefone do dono: ".$imovel['telefone_dono'];
$imagemSEO = $imovel['link_principal'];
$urlSEO = "https://127.0.0.1/compact/ver_imovel.php?id=".$imovel['id'];
?>

<!-- Open Graph -->
<meta property="og:image" content="<?php echo 'https://127.0.0.1/compact/' . $imagemSEO; ?>">
<meta property="og:title" content="<?php echo htmlspecialchars($tituloSEO); ?>">
<meta property="og:description" content="<?php echo htmlspecialchars($descricaoSEO); ?>">
<meta property="og:url" content="<?php echo $urlSEO; ?>">
<meta property="og:type" content="website">


<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo htmlspecialchars($tituloSEO); ?>">
<meta name="twitter:description" content="<?php echo htmlspecialchars($descricaoSEO); ?>">
<meta name="twitter:image" content=<?php echo 'https://127.0.0.1/compact/' . $imagemSEO; ?>">

<meta charset="UTF-8">
<title>Detalhes do Imóvel</title>
<style>
body {
  margin: 0;
  font-family: Arial, sans-serif;
  background: linear-gradient(135deg, #000000 50%, #b30000 50%);
  color: #fff;
  min-height: 100vh;
  padding: 20px;
}
.container {
  max-width: 900px;
  margin: auto;
  background: rgba(0,0,0,0.8);
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 0 15px rgba(255,0,0,0.6);
}
h2 { color: #ff3333; }
img {
  max-width: 100%;
  border-radius: 8px;
  margin: 10px 0;
}
.fotos {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}
.fotos img {
  width: 30%;
}
</style>
</head>
<body>
<div class="container">
    <p><strong>ID do Imóvel:</strong> <?php echo $imovel['id']; ?></p>
  <h2><?php echo $imovel['tipo']; ?> - <?php echo $imovel['contrato']; ?></h2>
  
  <p><strong>Quartos:</strong> <?php echo $imovel['dormitorios']; ?> | 
     <strong>Banheiros:</strong> <?php echo $imovel['banheiros']; ?> | 
     <strong>Garagem:</strong> <?php echo $imovel['garagem']; ?></p>
  <p><strong>Endereço:</strong> <?php echo $imovel['rua']." ".$imovel['numero'].", ".$imovel['bairro']." - ".$imovel['cidade']."/".$imovel['estado']; ?></p>
  <p><strong>Telefone:</strong> <?php echo $imovel['telefone']; ?>
   <strong>Dono:</strong> <?php echo $imovel['telefone_dono']; ?><br>
   <strong>Site:</strong> <?php echo $imovel['telefone_site']; ?>
   <p><strong>Preço:</strong> R$ <?php echo number_format($imovel['preco'], 2, ',', '.'); ?></p>

</p>

<!-- Botão WhatsApp -->
<?php if (!empty($imovel['telefone_site'])): ?>
  <?php 
    // Remove caracteres não numéricos para garantir formato correto
    $whatsapp = preg_replace('/\D/', '', $imovel['telefone_site']); 
  ?>
  <a href="https://api.whatsapp.com/send?phone=<?php echo $whatsapp; ?>" 
     target="_blank" 
     style="display:inline-block;padding:10px 15px;background:#25D366;color:#fff;
            border-radius:5px;text-decoration:none;font-weight:bold;">
     📲 Chamar no WhatsApp
  </a>
<?php endif; ?>


  <?php if (!empty($imovel['link_principal'])): ?>
    <h3>Foto Principal</h3>
    <img src="<?php echo $imovel['link_principal']; ?>" alt="Foto Principal">
  <?php endif; ?>

  <h3>Outras Fotos</h3>
  <div class="fotos">
    <?php foreach ($fotos as $foto): ?>
      <?php if ($foto['principal'] != 1): ?>
        <img src="<?php echo $foto['caminho']; ?>" alt="Foto do Imóvel">
      <?php endif; ?>
    <?php endforeach; ?>
  </div>
  <!-- Botão Copiar Link -->
<button onclick="copiarLink()" 
        style="display:inline-block;padding:10px 15px;background:#007bff;color:#fff;
               border-radius:5px;border:none;cursor:pointer;font-weight:bold;">
  📋 Copiar Link do Imóvel
</button>
<?php
session_start();


?>

<div class="option aura">
  <?php if ($total_transacoes === 0): ?>
    <!-- Botão aparece se não houver transação no dia -->
    <button 
      onclick="window.location.href='<?= $link_pagamento_aura ?>'" 
      style="width:100%;padding:15px;background:#e91e63;color:#fff;border:none;border-radius:8px;cursor:pointer;font-weight:bold;">
      ✨ Pagar com Aura - R$<?= number_format($valor_compra, 2, ',', '.') ?>
    </button>
  <?php else: ?>
    <!-- Mensagem aparece se já houver transação -->
    <p style="color:#999;font-weight:bold;">Já existe uma transação hoje para este compra_id.</p>
  <?php endif; ?>
</div>



<script>
function copiarLink() {
  // Monta o link atual da página com o ID do imóvel
  var link = window.location.href;
  navigator.clipboard.writeText(link).then(function() {
    alert("Link copiado para a área de transferência!");
  }, function() {
    alert("Não foi possível copiar o link.");
  });
}
</script>

</div>
</body>
</html>
