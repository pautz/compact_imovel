<?php
session_start();

// Conexão com o banco
$cx = new mysqli("127.0.0.1", "u839226731_cztuap", "Meu6595869Trator", "u839226731_meutrator");
if ($cx->connect_error) {
    die("Erro na conexão: " . $cx->connect_error);
}

$username = $_SESSION['username_odonto2'] ?? '';

// Se chegou até aqui, o usuário tem documento cadastrado e pode usar o formulário

/* --- CADASTRO DE IMÓVEL --- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cadastro'])) {
    $tipo = $_POST['tipo'];
    $contrato = $_POST['contrato'];
    $dormitorios = $_POST['dormitorios'];
    $banheiros = $_POST['banheiros'];
    $garagem = $_POST['garagem'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];
    $bairro = $_POST['bairro'];
    $rua = $_POST['rua'];
    $numero = $_POST['numero'];
    $cep = $_POST['cep'];
    $complemento = $_POST['complemento'];
    $telefone = $_POST['telefone'];
    $telefone_dono = $_POST['telefone_dono'];
    $telefone_site = $_POST['telefone_site'];

    // Pega o usuário logado
$username = $_SESSION['username_odonto2'] ?? '';

$preco = $_POST['preco'];

$stmt = $cx->prepare("INSERT INTO compact_imoveis 
    (tipo, contrato, preco, dormitorios, banheiros, garagem, cidade, estado, bairro, rua, numero, cep, complemento, telefone_dono, telefone_site, usuario_cadastro) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssdiiissssssssss", 
    $tipo, $contrato, $preco, $dormitorios, $banheiros, $garagem, 
    $cidade, $estado, $bairro, $rua, $numero, $cep, $complemento, 
    $telefone_dono, $telefone_site, $username
);

$stmt->execute();
$imovel_id = $stmt->insert_id;


    // Upload das fotos extras (máx. 9)
    if (!empty($_FILES['fotos']['name'][0])) {
        $totalFotos = count($_FILES['fotos']['name']);
        if ($totalFotos > 9) $totalFotos = 9;

        for ($i = 0; $i < $totalFotos; $i++) {
            $nomeArquivo = uniqid() . "_" . $_FILES['fotos']['name'][$i];
            $caminho = "uploads/" . $nomeArquivo;
            move_uploaded_file($_FILES['fotos']['tmp_name'][$i], $caminho);

            $stmtFoto = $cx->prepare("INSERT INTO compact_fotos (imovel_id, caminho, principal) VALUES (?, ?, 0)");
            $stmtFoto->bind_param("is", $imovel_id, $caminho);
            $stmtFoto->execute();
        }
    }

    // Upload da foto principal
    if (!empty($_FILES['foto_principal']['name'])) {
        $nomePrincipal = uniqid() . "_" . $_FILES['foto_principal']['name'];
        $caminhoPrincipal = "uploads/" . $nomePrincipal;
        move_uploaded_file($_FILES['foto_principal']['tmp_name'], $caminhoPrincipal);

        $stmtLink = $cx->prepare("UPDATE compact_imoveis SET link_principal=? WHERE id=?");
        $stmtLink->bind_param("si", $caminhoPrincipal, $imovel_id);
        $stmtLink->execute();

        $stmtFoto = $cx->prepare("INSERT INTO compact_fotos (imovel_id, caminho, principal) VALUES (?, ?, 1)");
        $stmtFoto->bind_param("is", $imovel_id, $caminhoPrincipal);
        $stmtFoto->execute();
    }

    echo "<p style='color:lime;'>Imóvel cadastrado com sucesso!</p>";
}
?>
<style>/* Fundo bicolor em gradiente */
body {
  margin: 0;
  font-family: Arial, sans-serif;
  background: linear-gradient(135deg, #000000 50%, #b30000 50%);
  color: #fff;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  padding: 20px;
}

.form-container {
  background: rgba(0, 0, 0, 0.85);
  padding: 20px;
  border-radius: 10px;
  width: 100%;
  max-width: 600px;
  box-shadow: 0 0 15px rgba(255, 0, 0, 0.6);
}

label {
  display: block;
  margin-top: 15px;
  font-weight: bold;
  color: #ff3333;
}

input, select, button {
  width: 100%;
  padding: 10px;
  margin-top: 5px;
  margin-bottom: 15px;
  border: none;
  border-radius: 5px;
  font-size: 1em;
}

input, select {
  background: #1a1a1a;
  color: #fff;
}

input[type="file"] {
  background: transparent;
  color: #fff;
}

button {
  background: #b30000;
  color: #fff;
  font-weight: bold;
  cursor: pointer;
  margin-top: 20px;
  transition: 0.3s;
}

button:hover {
  background: #ff1a1a;
}

/* Linha com colunas */
.row {
  display: flex;
  gap: 10px;
}
.row .col {
  flex: 1;
}

/* Responsividade */
@media (max-width: 768px) {
  .row {
    flex-direction: column;
  }
}

</style>
<div class="form-container">
  <form method="POST" enctype="multipart/form-data">
    <input type="hidden" name="cadastro" value="1">

    <label>Tipo:</label>
    <select name="tipo">
      <option>Quarto</option> 
      <option>Apartamento</option>
      <option>Casa</option>
      <option>Chácara</option>
      <option>Comercial</option>
      <option>Sítio</option>
      <option>Terreno</option>
    </select>

    <label>Contrato:</label>
    <select name="contrato">
      <option>Aluguel</option>
    </select>

    <!-- Linha com dormitórios, banheiros e garagem -->
    <div class="row">
      <div class="col">
        <label>Dormitórios:</label>
        <input type="number" name="dormitorios" min="0" placeholder="Ex: 3">
      </div>
      <div class="col">
        <label>Banheiros:</label>
        <input type="number" name="banheiros" min="0" placeholder="Ex: 2">
      </div>
      <div class="col">
        <label>Garagem:</label>
        <input type="number" name="garagem" min="0" placeholder="Ex: 1">
      </div>
    </div>

    <label>Cidade:</label>
    <input type="text" name="cidade" required>

    <label>Estado:</label>
    <input type="text" name="estado" required>

    <label>Bairro:</label>
    <input type="text" name="bairro" required>

    <label>Rua:</label>
    <input type="text" name="rua" required>

    <label>Número:</label>
    <input type="text" name="numero" required>

    <label>CEP:</label>
    <input type="text" name="cep" required>

    <label>Complemento:</label>
    <input type="text" name="complemento">

    <label>Telefone do Dono:</label>
    <input type="text" name="telefone_dono" required>

    <label>Telefone do Site:</label>
    <input type="text" name="telefone_site" required>
<label>Preço:</label>
<input type="number" step="0.01" name="preco" placeholder="Ex: 1500.00" required>

    <label>Fotos (máx. 9):</label>
    <input type="file" name="fotos[]" multiple accept="image/*">

    <label>Foto Principal:</label>
    <input type="file" name="foto_principal" accept="image/*">

    <button type="submit">Cadastrar</button>
  </form>
</div>

