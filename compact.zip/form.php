<?php
// Conexão com o banco
$cx = new mysqli("127.0.0.1", "u839226731_cztuap", "Meu6595869Trator", "u839226731_meutrator");
if ($cx->connect_error) {
    die("Erro na conexão: " . $cx->connect_error);
}

/* --- CADASTRO DE IMÓVEL --- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cadastro'])) {
    $tipo = $_POST['tipo'];
    $contrato = $_POST['contrato'];
    $dormitorios = $_POST['dormitorios'];
    $banheiros = $_POST['banheiros'];
    $garagem = $_POST['garagem'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];
    $bairro = $_POST['bairro'];
    $rua = $_POST['rua'];
    $numero = $_POST['numero'];
    $cep = $_POST['cep'];
    $complemento = $_POST['complemento'];
    $telefone_dono = $_POST['telefone_dono'];
    $telefone_site = $_POST['telefone_site'];
    $preco = $_POST['preco'];

    // Usuário fixo (sem login)
    $username = 'publico';

    $stmt = $cx->prepare("INSERT INTO compact_imoveis 
        (tipo, contrato, preco, dormitorios, banheiros, garagem, cidade, estado, bairro, rua, numero, cep, complemento, telefone_dono, telefone_site, usuario_cadastro) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdiiissssssssss", 
        $tipo, $contrato, $preco, $dormitorios, $banheiros, $garagem, 
        $cidade, $estado, $bairro, $rua, $numero, $cep, $complemento, 
        $telefone_dono, $telefone_site, $username
    );
    $stmt->execute();
    $imovel_id = $stmt->insert_id;

    // Upload das fotos extras
    if (!empty($_FILES['fotos']['name'][0])) {
        $totalFotos = count($_FILES['fotos']['name']);
        if ($totalFotos > 9) $totalFotos = 9;
        for ($i = 0; $i < $totalFotos; $i++) {
            $nomeArquivo = uniqid() . "_" . $_FILES['fotos']['name'][$i];
            $caminho = "uploads/" . $nomeArquivo;
            move_uploaded_file($_FILES['fotos']['tmp_name'][$i], $caminho);
            $stmtFoto = $cx->prepare("INSERT INTO compact_fotos (imovel_id, caminho, principal) VALUES (?, ?, 0)");
            $stmtFoto->bind_param("is", $imovel_id, $caminho);
            $stmtFoto->execute();
        }
    }

    // Upload da foto principal
    if (!empty($_FILES['foto_principal']['name'])) {
        $nomePrincipal = uniqid() . "_" . $_FILES['foto_principal']['name'];
        $caminhoPrincipal = "uploads/" . $nomePrincipal;
        move_uploaded_file($_FILES['foto_principal']['tmp_name'], $caminhoPrincipal);
        $stmtLink = $cx->prepare("UPDATE compact_imoveis SET link_principal=? WHERE id=?");
        $stmtLink->bind_param("si", $caminhoPrincipal, $imovel_id);
        $stmtLink->execute();
        $stmtFoto = $cx->prepare("INSERT INTO compact_fotos (imovel_id, caminho, principal) VALUES (?, ?, 1)");
        $stmtFoto->bind_param("is", $imovel_id, $caminhoPrincipal);
        $stmtFoto->execute();
    }

    echo "<p style='color:lime;'>Imóvel cadastrado com sucesso!</p>";
}
?>
