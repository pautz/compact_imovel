<?php
// Conexão com o banco
$cx = new mysqli("127.0.0.1", "u839226731_cztuap", "Meu6595869Trator", "u839226731_meutrator");
if ($cx->connect_error) {
    die("Erro na conexão: " . $cx->connect_error);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Painel - Carlito's Imóveis</title>
<style>
body {
  margin: 0;
  font-family: Arial, sans-serif;
  background: #111;
  color: #fff;
}
.header {
  background: #b30000;
  padding: 15px;
  text-align: center;
  font-size: 1.5em;
  font-weight: bold;
}
.container {
  display: flex;
  min-height: 100vh;
}
.sidebar {
  width: 250px;
  background: #000;
  padding: 20px;
  transition: all 0.3s ease;
}
.sidebar h3 {
  color: #ff3333;
  margin-bottom: 10px;
}
.sidebar a {
  display: block;
  padding: 10px;
  margin-bottom: 8px;
  background: #1a1a1a;
  color: #fff;
  text-decoration: none;
  border-radius: 5px;
}
.sidebar a:hover {
  background: #b30000;
}
.content {
  flex: 1;
  padding: 20px;
}

/* Responsividade */
@media (max-width: 768px) {
  .container {
    flex-direction: column;
  }
  .sidebar {
    width: 100%;
    display: none; /* escondido por padrão em telas pequenas */
  }
  .sidebar.active {
    display: block; /* aparece quando o menu é aberto */
  }
  .menu-toggle {
    background: #b30000;
    color: #fff;
    padding: 10px;
    text-align: center;
    cursor: pointer;
    font-weight: bold;
  }
}
</style>
</head>
<body>
<div class="header">Painel Carlito's Imóveis</div>

<!-- Botão de menu para mobile -->
<div class="menu-toggle" onclick="toggleMenu()">☰ Menu</div>

<div class="container">
  <div class="sidebar" id="sidebar">
    <h3>Imóveis</h3>
    <a href="form.php">Cadastrar Imóvel</a>
    <a href="meus_imoveis.php">Meus Imóveis</a>
    <h3>Usuário</h3>
    <a href="index.php">Todos Imóveis</a>
    <a href="logout.php">Sair</a>
  </div>
  <div class="content">
    <h2>Bem-vindo ao Painel</h2>
    <p>Selecione uma opção no menu para gerenciar seus imóveis.</p>
  </div>
</div>

<script>
function toggleMenu() {
  document.getElementById("sidebar").classList.toggle("active");
}
</script>
</body>
</html>
